enum PossiblePaymentMethods { wallet, creditCard }
