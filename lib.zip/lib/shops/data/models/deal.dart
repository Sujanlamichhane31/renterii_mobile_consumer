// ignore_for_file: public_member_api_docs, sort_constructors_first


class Deal {
  String title;
  String description;
  String promoCode;
  double percentage;

  Deal({
    required this.title,
    required this.description,
    required this.promoCode,
    required this.percentage
  });

  
}
